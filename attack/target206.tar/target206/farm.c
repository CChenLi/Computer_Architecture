/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_280(unsigned x)
{
    return x + 3281031256U;
}

unsigned addval_384(unsigned x)
{
    return x + 2974270232U;
}

unsigned getval_152()
{
    return 2428995916U;
}

unsigned addval_156(unsigned x)
{
    return x + 2428995912U;
}

unsigned getval_221()
{
    return 3284633928U;
}

unsigned addval_408(unsigned x)
{
    return x + 2455288840U;
}

void setval_104(unsigned *p)
{
    *p = 3281016915U;
}

unsigned getval_363()
{
    return 3284633929U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_125()
{
    return 2497743176U;
}

void setval_267(unsigned *p)
{
    *p = 3224426121U;
}

unsigned addval_171(unsigned x)
{
    return x + 3525364361U;
}

void setval_196(unsigned *p)
{
    *p = 3229928105U;
}

unsigned getval_467()
{
    return 3523794633U;
}

unsigned addval_246(unsigned x)
{
    return x + 3525362057U;
}

void setval_272(unsigned *p)
{
    *p = 2430634312U;
}

unsigned getval_361()
{
    return 3525886345U;
}

unsigned addval_100(unsigned x)
{
    return x + 3230976649U;
}

void setval_332(unsigned *p)
{
    *p = 3674789505U;
}

void setval_203(unsigned *p)
{
    *p = 3223377545U;
}

void setval_240(unsigned *p)
{
    *p = 2425405825U;
}

unsigned getval_472()
{
    return 3284828565U;
}

unsigned addval_159(unsigned x)
{
    return x + 3372269961U;
}

unsigned getval_291()
{
    return 3286272320U;
}

unsigned getval_470()
{
    return 3221277321U;
}

unsigned addval_455(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_185(unsigned x)
{
    return x + 2425408137U;
}

unsigned getval_137()
{
    return 3531921033U;
}

unsigned getval_421()
{
    return 3281049217U;
}

unsigned getval_293()
{
    return 2464188744U;
}

unsigned addval_343(unsigned x)
{
    return x + 3252717896U;
}

unsigned getval_222()
{
    return 3374891401U;
}

void setval_457(unsigned *p)
{
    *p = 3380920715U;
}

unsigned getval_422()
{
    return 2445379872U;
}

unsigned addval_437(unsigned x)
{
    return x + 3525891721U;
}

unsigned addval_417(unsigned x)
{
    return x + 3246997382U;
}

unsigned getval_101()
{
    return 3281180297U;
}

void setval_353(unsigned *p)
{
    *p = 3767126031U;
}

unsigned addval_271(unsigned x)
{
    return x + 2425408139U;
}

unsigned getval_368()
{
    return 3374893705U;
}

void setval_265(unsigned *p)
{
    *p = 2497743176U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
